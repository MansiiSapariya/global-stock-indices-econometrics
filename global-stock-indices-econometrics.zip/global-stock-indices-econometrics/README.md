# Global Stock Indices Econometric Analysis

> Econometric analysis of global stock indices using stationarity testing, first-difference transformation, price-based regression, and Granger causality analysis.

## About the Project

This project studies the behavior and interdependence of 12 global stock market indices using daily price and return series.

The analysis covers **April 2009 to December 2011** with **433 daily observations**. The work was conducted using EViews and focuses on two main areas:

- Price-based regression analysis
- Return-based Granger causality analysis

The study first evaluates the stationarity of index price series and transforms non-stationary variables through first-order differencing. It then examines short-term predictive relationships between global markets and the NIFTY 50.

## Indices Covered

- NIFTY 50
- FTSE 100
- DAX
- CAC 40
- NIKKEI 225
- NASDAQ
- BOVESPA
- Shanghai
- TASI
- TA 35
- TSX
- ADX

## Methodology

```text
Global Stock Index Data
        ↓
Price-Level Analysis
        ↓
ADF Unit Root Tests
        ↓
First-Order Differencing
        ↓
Stationarity Verification
        ↓
Price-Based Regression
        ↓
Return Series Analysis
        ↓
Granger Causality Tests
        ↓
Market Interdependence Analysis
```

## Stationarity Analysis

The Augmented Dickey-Fuller test was applied to the index price series.

At the 5% significance level, **11 of the 12 indices were non-stationary in levels**. TASI was the only series reported as stationary at level, with a p-value of 0.0180. The remaining non-stationary series were transformed using first-order differences, after which the differenced series were reported as stationary. fileciteturn5file0L75-L97 fileciteturn5file0L148-L173

## Granger Causality Analysis

The Granger causality analysis uses the stationary return series to examine short-term predictive relationships and information spillovers between global markets and the NIFTY 50. fileciteturn7file3L103-L121

The reported results found statistically significant Granger causality from **8 of the 11 tested global indices** to NIFTY 50 returns:

- BOVESPA
- CAC 40
- DAX
- FTSE 100
- NASDAQ
- TA 35
- TASI
- TSX

ADX, NIKKEI, and SHANGAI were reported as having no significant Granger-causal relationship with NIFTY 50 returns. fileciteturn7file6L259-L271

## Key Findings

- Most global index price series are non-stationary at levels.
- First-order differencing produces stationary series suitable for further time-series analysis.
- Global equity markets display substantial short-term interdependence.
- European, North American, and selected Middle Eastern indices show significant predictive relationships with NIFTY 50 returns in the reported Granger causality tests.
- NIKKEI and SHANGAI do not show significant Granger causality toward NIFTY 50 in the reported results.

## Repository Structure

```text
global-stock-indices-econometrics/
│
├── README.md
│
└── docs/
    └── Lab03_Econometrics.pdf
```

## Source File

The repository contains the complete submitted analysis as a PDF under `docs/`.

No raw dataset, EViews workfile, or executable EViews project file was provided with this project. Therefore, this repository preserves the documented analysis and results rather than recreating unavailable source files.

## Tools

- EViews
- Augmented Dickey-Fuller Test
- First-Order Differencing
- Time-Series Analysis
- Granger Causality Test
- Financial Market Analysis

## Author

**Mansi Sapariya**

Course: **Econometrics**  
Course Code: **MDS531A**

## Disclaimer

This repository contains an academic econometrics project for educational purposes. The findings should not be interpreted as financial advice or investment recommendations.
